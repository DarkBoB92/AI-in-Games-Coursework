Controls:
Move Up - W
Move Down - S
Move Right - D
Move Left - A
Zoom In - Q/Mouse Scroll Up
Zoom Out - E/Mouse Scroll Down

Input Fields:
The two input fields are for the size of the Grid, accepting only integer numbers. If none given, the default size is 10x10

Checkboxes:
The two checkboxes determine which rule is in place. Use Conway Rule to have the standard Game of Life. Use BoB Rule to have a twisted Game of Life, with different B/S ratio.
If none is selected it goes to Default that is Conway's Rule. If both are selected, the two rules live together in the grid system.

These checkboxes determine how you can fill the Grid. With Conway Rule you have Black painted tiles, as with BoB Rule you have Red painted tiles. Be aware, when both checkboxes are selected, you will automatically paint only with BoB rule, you have to have them selected individual while filling the Grid.

Dropdown:
The dropdown let you select which neighbourhood you want to check. And these are:
Moore - standard 8 cells around the central one
Plus - from the central cell checking top, bottom, right and left
Cross - from the central cell checking diagonally, top left, top right, bottom left and bottom right
2x3 Directional Block - from the central cell checks individually for the for direction a 2x3 cell space above, below, right and left 

Buttons:
Generate Grid - Generates a tile based grid with the size given by, otherwise defaults in 10x10
Step - Generates and visualise the only the next generation step by step
Start - Saves the current layout and Runs continuously the whole cycle until stopped
Stop - Stops the running life cycle
Save - Saves the current layout of the grid
Reset - Resets the grid with the saved layout
Clear - Clears the whole grid blank 